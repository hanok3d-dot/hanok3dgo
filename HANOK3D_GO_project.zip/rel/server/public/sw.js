/* HANOK3D GO 서비스 워커: 소개 페이지와 게임 페이지를 저장해 두어 인터넷이 끊겨도 AI·친선 대국은 실행 (온라인 대국은 서버 필요) */
const CACHE = "hanok3d-v3";
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(["/game.html"])).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin || u.pathname.startsWith("/socket.io")) return;
  if (e.request.mode === "navigate") {                       // 네트워크 우선, 안 되면 저장본 (초대 링크는 게임 페이지로)
    const key = /^\/(j\/\d{4}|game(\.html)?)\/?$/.test(u.pathname) ? "/game.html" : u.pathname;
    e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put(key, c)); return r; }).catch(() => caches.match(key)));
  }
});
