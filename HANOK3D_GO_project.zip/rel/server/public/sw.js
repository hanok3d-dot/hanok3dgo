/* HANOK3D GO 서비스 워커: 게임 페이지를 저장해 두어 인터넷이 끊겨도 AI·친선 대국은 실행 (온라인 대국은 서버 필요) */
const CACHE = "hanok3d-v2";
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(["/"])).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin || u.pathname.startsWith("/socket.io")) return;
  if (e.request.mode === "navigate") {                       // 게임 페이지: 네트워크 우선, 안 되면 저장본
    e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put("/", c)); return r; }).catch(() => caches.match("/")));
  }
});
