/* 서버 자동 시험: 세 판 모두 랜덤 매칭 · 초대 · 착수 검증 · 불법 수 거부 · 재접속 */
"use strict";
process.env.PORT = process.env.PORT || "3999";
process.env.DATA_DIR = require("os").tmpdir() + "/hanok3d-test";
const { server } = require("./server.js");
const { io } = require("socket.io-client");
const URL = "http://localhost:" + process.env.PORT;
const pid = () => require("crypto").randomBytes(16).toString("hex");
const call = (s, ev, d) => new Promise(r => s.emit(ev, d, r));
const once = (s, ev) => new Promise(r => s.once(ev, r));
const conn = () => new Promise(r => { const s = io(URL, { transports: ["websocket"] }); s.on("connect", () => r(s)); });
let fail = 0;
const check = (cond, label) => { console.log((cond ? "  ✔ " : "  ✖ ") + label); if (!cond) fail++; };

async function playBoard(n, l, how) {
  const a = await conn(), b = await conn();
  const hello = await call(a, "hello", { v: 2 });
  check(hello.v === 2, `hello v2 (${l}x${n}x${n})`);
  const sa = once(a, "start"), sb = once(b, "start");
  if (how === "quick") {
    const r1 = await call(a, "quick", { v: 2, n, l, name: "A", pid: pid() });
    const st = await call(a, "stats", null);
    check(r1.ok && st.waiting[`${l}x${n}x${n}`] === 1, `quick 대기열 ${l}x${n}x${n} = 1명`);
    await call(b, "quick", { v: 2, n, l, name: "B", pid: pid() });
  } else {
    const c = await call(a, "create", { v: 2, n, l, name: "A", time: 30, pid: pid() });
    check(c.ok && /^\d{4}$/.test(c.code), `invite 코드 ${c.code}`);
    const j = await call(b, "join", { v: 2, code: c.code, name: "B", boards: [{ n, l }], pid: pid() });
    check(j.ok, "join 성공");
  }
  const [ra, rb] = await Promise.all([sa, sb]);
  check(ra.n === n && ra.l === l && ra.room === rb.room && ra.color + rb.color === 3, `start: 판 ${ra.l}x${ra.n}x${ra.n}, 색 ${ra.color}/${rb.color}, 덤 ${ra.komi}`);
  const black = ra.color === 1 ? [a, ra] : [b, rb], white = ra.color === 1 ? [b, rb] : [a, ra];
  // 흑 착수 → 백이 받음
  const got = once(white[0], "ev");
  const m1 = await call(black[0], "ev", { room: ra.room, ev: { t: "m", i: 0, c: 1, s: 0 } });
  const e1 = await got;
  check(m1.ok && e1.t === "m" && e1.i === 0, "흑 착수 전달");
  // 같은 자리 착수(불법) → 거부
  const bad = await call(white[0], "ev", { room: ra.room, ev: { t: "m", i: 0, c: 2, s: 1 } });
  check(!bad.ok, "이미 돌이 있는 자리 거부");
  // 상대 차례에 두기 → 거부
  const bad2 = await call(black[0], "ev", { room: ra.room, ev: { t: "m", i: 1, c: 1, s: 1 } });
  check(!bad2.ok, "상대 차례 착수 거부");
  // 마지막 칸(판 크기 경계) 착수
  const last = n * n * l - 1;
  const m2 = await call(white[0], "ev", { room: ra.room, ev: { t: "m", i: last, c: 2, s: 1 } });
  check(m2.ok, `마지막 칸(${last}) 착수 허용`);
  const m3 = await call(black[0], "ev", { room: ra.room, ev: { t: "m", i: last + 1, c: 1, s: 2 } });
  check(!m3.ok, `판 밖(${last + 1}) 착수 거부`);
  // 재접속
  const tokB = black[1].token;
  black[0].disconnect();
  await once(white[0], "opp_status");
  const nb = await conn();
  const rj = await call(nb, "rejoin", { room: ra.room, token: tokB });
  check(rj.ok && rj.events.length === 2, "재접속 후 기록 2수 복구");
  // 기권
  const rs = await call(nb, "ev", { room: ra.room, ev: { t: "r", c: 1, s: 2 } });
  check(rs.ok, "기권 처리");
  [a, b, nb].forEach(s => s.close());
}

(async () => {
  for (const [n, l] of [[3, 3], [5, 3], [7, 2]]) {
    console.log(`\n▶ ${l}${n}${n} 랜덤 매칭`); await playBoard(n, l, "quick");
    console.log(`▶ ${l}${n}${n} 친구 초대`); await playBoard(n, l, "invite");
  }
  // 옛 앱(3×3×3만 아는 앱)이 355 초대에 들어오면 안내
  const a = await conn(), b = await conn();
  const c = await call(a, "create", { v: 2, n: 5, l: 3, name: "A", pid: pid() });
  const j = await call(b, "join", { code: c.code, name: "Old", sizes: [3] });
  check(!j.ok && /355/.test(j.msg), "옛 앱 → 355 초대 거부 안내");
  a.close(); b.close();
  const h = await fetch(URL + "/health").then(r => r.json());
  check(h.v === 2 && h.boards.length === 3, "/health v2 · 판 3종");
  const jpage = await fetch(URL + "/j/1234");
  check(jpage.status === 200, "/j/1234 초대 링크 → 게임 페이지");
  console.log(fail ? `\n실패 ${fail}건` : "\n모든 시험 통과");
  server.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
