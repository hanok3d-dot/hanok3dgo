/* =====================================================================
   HANOK3D GO 대국 서버 v2 (Node.js + Express + Socket.IO)
   - 세 가지 판 모두 지원: 333(3×3×3) · 355(3×5×5) · 277(2×7×7)
   - 서버 권위 판정: 모든 수를 rules.js(게임 HTML의 규칙 엔진에서 추출)로 검증한 뒤 상대에게 전달
   - 랜덤 매칭(판별 대기열) · 친구 초대(4자리 코드, 10분 유효) · 재접속 60초 유예 · 재대국 · 간단 레이팅
   - 게임 페이지(public/index.html)와 초대 링크(/j/1234)도 함께 제공 → 웹에서는 이 주소가 곧 대국 서버
   실행: npm install && npm start   (PORT 환경 변수, 기본 3000)
   ===================================================================== */
"use strict";
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const http = require("http");
const express = require("express");
const { Server } = require("socket.io");
const Rules = require("./rules.js");

const PORT = +process.env.PORT || 3000;
const PROTOCOL_V = 2;
const GRACE_SEC = 60;                 // 연결이 끊긴 대국자를 기다리는 시간
const INVITE_TTL_MS = 10 * 60 * 1000; // 초대 방 유효 시간
const QUICK_TIME = 60;                // 랜덤 매칭 한 수 시간(초)
const TIME_SLACK_MS = 4000;           // 시간 초과 판정 여유 (기기 시계·전송 지연)

/* 지원 판: 키 = "층x칸x칸" (게임 화면 MODES와 같은 덤) */
const BOARDS = {
  "3x3x3": { n: 3, l: 3, komi: 0.5, code: "333" },
  "3x5x5": { n: 5, l: 3, komi: 3.5, code: "355" },
  "2x7x7": { n: 7, l: 2, komi: 4.5, code: "277" },
};
const boardKey = (n, l) => `${l || n}x${n}x${n}`;
const findBoard = (n, l) => BOARDS[boardKey(+n, +(l || n))] || null;

/* ---------------- 레이팅 (기기별 무작위 ID의 해시만 저장, 개인정보 없음) ---------------- */
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const RATING_FILE = path.join(DATA_DIR, "ratings.json");
let ratings = {};
try { ratings = JSON.parse(fs.readFileSync(RATING_FILE, "utf8")); } catch (e) { ratings = {}; }
let saveTimer = 0;
function saveRatings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(RATING_FILE, JSON.stringify(ratings)); } catch (e) { console.warn("rating save:", e.message); }
  }, 1500);
}
const pidHash = pid => /^[a-f0-9]{32}$/.test(String(pid || "")) ? crypto.createHash("sha256").update("hanok3d:" + pid).digest("hex").slice(0, 24) : "";
const getRating = (h, bk) => (h && ratings[h] && ratings[h][bk]) || 1500;
function updateRatings(room) {
  const g = room.game;
  if (!g || !g.result || room.rated) return;
  room.rated = true;
  const [a, b] = room.players;                       // a = 흑(1), b = 백(2)
  if (!a.hash || !b.hash || a.hash === b.hash) return;
  const bk = room.bk, ra = getRating(a.hash, bk), rb = getRating(b.hash, bk);
  const sa = g.result.winner === 1 ? 1 : g.result.winner === 2 ? 0 : 0.5;
  const ea = 1 / (1 + Math.pow(10, (rb - ra) / 400)), K = 24;
  const na = Math.round(ra + K * (sa - ea)), nb = Math.round(rb + K * ((1 - sa) - (1 - ea)));
  (ratings[a.hash] = ratings[a.hash] || {})[bk] = na;
  (ratings[b.hash] = ratings[b.hash] || {})[bk] = nb;
  saveRatings();
}

/* ---------------- HTTP ---------------- */
const app = express();
app.disable("x-powered-by");
const PUBLIC = path.join(__dirname, "public");
/* /           → 소개 페이지(index.html). 없으면 게임
   /game.html  → 게임 (game.html이 없으면 옛 구성대로 index.html이 게임) */
const GAME_FILE = () => fs.existsSync(path.join(PUBLIC, "game.html")) ? "game.html" : "index.html";
const sendGame = (req, res) => res.sendFile(path.join(PUBLIC, GAME_FILE()));
app.get("/", (req, res) => res.sendFile(path.join(PUBLIC, "index.html")));
app.get(["/game", "/game.html"], sendGame);
app.get("/j/:code", (req, res, next) => /^\d{4}$/.test(req.params.code) ? sendGame(req, res) : next());   // 초대 링크 → 게임 페이지가 코드를 읽어 바로 입장
app.get("/privacy", (req, res) => res.sendFile(path.join(__dirname, "privacy.html")));
app.get("/health", (req, res) => res.json({ ok: true, v: PROTOCOL_V, boards: Object.keys(BOARDS), uptime: Math.round(process.uptime()) }));
app.get("/.well-known/assetlinks.json", (req, res) => {                // 안드로이드 앱 링크 (초대 링크를 앱으로 열기)
  res.type("application/json");
  try { res.send(fs.readFileSync(path.join(__dirname, "assetlinks.json"), "utf8")); } catch (e) { res.send("[]"); }
});
app.use(express.static(PUBLIC, { index: false, maxAge: "1h" }));

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: false },   // 앱(capacitor://localhost, file://)에서도 연결
  pingInterval: 20000, pingTimeout: 20000,
});

/* ---------------- 상태 ---------------- */
const rooms = new Map();          // roomId → room
const codes = new Map();          // 초대 코드 → roomId
const queues = {};                // bk → [{ sock, name, hash }]
Object.keys(BOARDS).forEach(k => { queues[k] = []; });
const sockRoom = new Map();       // socket.id → roomId (대국 중·초대 대기 중)

const rid = () => crypto.randomBytes(9).toString("base64url");
const tok = () => crypto.randomBytes(18).toString("base64url");
const cleanName = s => String(s || "").replace(/[\u0000-\u001f<>]/g, "").trim().slice(0, 12) || "손님";
function newCode() {
  for (let k = 0; k < 50; k++) { const c = String(1000 + crypto.randomInt(9000)); if (!codes.has(c)) return c; }
  return null;
}
const ack = (cb, v) => { if (typeof cb === "function") cb(v); };

function makePlayer(sock, name, hash) {
  return { name: cleanName(name), hash, token: tok(), sid: sock ? sock.id : "", online: !!sock, graceTimer: 0 };
}
function emitTo(p, ev, data) { if (p && p.sid) io.to(p.sid).emit(ev, data); }

/* 대국 시작: players[0] = 흑 */
function startGame(room) {
  const B = BOARDS[room.bk];
  room.game = Rules.createGame(B.n, B.komi, B.l);
  room.events = [];
  room.state = "play";
  room.rated = false;
  room.turnStart = Date.now();
  room.rematch = [false, false];
  if (room.code) { codes.delete(room.code); room.code = ""; }
  clearTimeout(room.expire);
  room.players.forEach((p, k) => {
    const opp = room.players[1 - k];
    if (p.sid) sockRoom.set(p.sid, room.id);
    emitTo(p, "start", {
      room: room.id, token: p.token, color: k + 1, n: B.n, l: B.l, board: room.bk,
      me: p.name, opp: opp.name, myRating: p.hash ? getRating(p.hash, room.bk) : 0, oppRating: opp.hash ? getRating(opp.hash, room.bk) : 0,
      komi: B.komi, time: room.time, events: [],
    });
  });
}

function seatOf(room, sock) { return room.players.findIndex(p => p.sid === sock.id); }

function endRoom(room) {
  room.players.forEach(p => { clearTimeout(p.graceTimer); if (p.sid) sockRoom.delete(p.sid); });
  if (room.code) codes.delete(room.code);
  clearTimeout(room.expire);
  rooms.delete(room.id);
}

function removeFromQueues(sock) {
  for (const k of Object.keys(queues)) queues[k] = queues[k].filter(q => q.sock.id !== sock.id);
}

/* 초대 방(아직 시작 전)을 정리 */
function closePending(room, notify) {
  if (!room || room.state !== "pending") return;
  if (notify) room.players.forEach(p => emitTo(p, "room_closed", {}));
  endRoom(room);
}

/* ---------------- 소켓 ---------------- */
io.on("connection", sock => {
  sock.on("hello", (d, cb) => ack(cb, { ok: true, v: PROTOCOL_V, boards: Object.keys(BOARDS).map(k => ({ key: k, n: BOARDS[k].n, l: BOARDS[k].l, code: BOARDS[k].code })) }));

  sock.on("stats", (d, cb) => {
    let playing = 0;
    for (const r of rooms.values()) if (r.state === "play") playing += 2;
    const waiting = {};
    for (const k of Object.keys(queues)) waiting[k] = queues[k].length;
    ack(cb, { online: io.engine.clientsCount, playing, waiting });
  });

  /* 랜덤 매칭: 같은 판을 고른 사람끼리 */
  sock.on("quick", (d, cb) => {
    d = d || {};
    const B = findBoard(d.n, d.l);
    if (!B) return ack(cb, { ok: false, msg: "지원하지 않는 판입니다. 앱을 최신 버전으로 업데이트해 주세요." });
    if (sockRoom.has(sock.id)) return ack(cb, { ok: false, msg: "이미 대국 중이거나 초대를 기다리는 중입니다." });
    const bk = boardKey(B.n, B.l), hash = pidHash(d.pid);
    removeFromQueues(sock);
    const q = queues[bk];
    const idx = q.findIndex(x => x.sock.connected && x.sock.id !== sock.id && (!hash || x.hash !== hash));
    if (idx < 0) { q.push({ sock, name: d.name, hash }); return ack(cb, { ok: true, waiting: true }); }
    const other = q.splice(idx, 1)[0];
    ack(cb, { ok: true });
    const pa = makePlayer(other.sock, other.name, other.hash), pb = makePlayer(sock, d.name, hash);
    const room = { id: rid(), bk, time: QUICK_TIME, players: crypto.randomInt(2) ? [pa, pb] : [pb, pa], state: "play", code: "" };
    rooms.set(room.id, room);
    startGame(room);
  });

  /* 친구 초대: 방 만들기 → 4자리 코드 */
  sock.on("create", (d, cb) => {
    d = d || {};
    const B = findBoard(d.n, d.l);
    if (!B) return ack(cb, { ok: false, msg: "지원하지 않는 판입니다." });
    if (sockRoom.has(sock.id)) { const old = rooms.get(sockRoom.get(sock.id)); if (old && old.state === "pending") closePending(old, false); else return ack(cb, { ok: false, msg: "이미 대국 중입니다." }); }
    removeFromQueues(sock);
    const code = newCode();
    if (!code) return ack(cb, { ok: false, msg: "잠시 뒤 다시 시도해 주세요." });
    const time = [30, 60, 120, 180].includes(+d.time) ? +d.time : 60;
    const host = makePlayer(sock, d.name, pidHash(d.pid));
    const room = { id: rid(), bk: boardKey(B.n, B.l), time, players: [host], state: "pending", code };
    room.expire = setTimeout(() => closePending(room, true), INVITE_TTL_MS);
    rooms.set(room.id, room); codes.set(code, room.id); sockRoom.set(sock.id, room.id);
    ack(cb, { ok: true, room: room.id, token: host.token, code, board: room.bk });
  });

  /* 초대 코드로 들어가기 */
  sock.on("join", (d, cb) => {
    d = d || {};
    const code = String(d.code || "").replace(/\D/g, "").slice(0, 4);
    const room = rooms.get(codes.get(code));
    if (!room || room.state !== "pending") return ack(cb, { ok: false, msg: "방을 찾을 수 없습니다. 코드가 맞는지, 10분이 지나지 않았는지 확인하세요." });
    const B = BOARDS[room.bk];
    const can = Array.isArray(d.boards) ? d.boards.some(b => +b.n === B.n && +(b.l || b.n) === B.l)
      : Array.isArray(d.sizes) && B.n === B.l && d.sizes.map(Number).includes(B.n);            // 옛 앱은 정육면체만
    if (!can) return ack(cb, { ok: false, msg: `이 초대는 ${B.code}(${room.bk.replace(/x/g, "×")}) 판입니다. 앱을 최신 버전으로 업데이트해 주세요.` });
    if (room.players[0].sid === sock.id) return ack(cb, { ok: false, msg: "내가 만든 방에는 직접 들어갈 수 없습니다." });
    removeFromQueues(sock);
    const guest = makePlayer(sock, d.name, pidHash(d.pid));
    const host = room.players[0];
    room.players = crypto.randomInt(2) ? [host, guest] : [guest, host];
    sockRoom.set(sock.id, room.id);
    if (!host.online) { room.waitingHost = true; return ack(cb, { ok: true, hostAway: true }); }
    ack(cb, { ok: true });
    startGame(room);
  });

  sock.on("cancel", () => {
    removeFromQueues(sock);
    const room = rooms.get(sockRoom.get(sock.id));
    if (room && room.state === "pending") closePending(room, true);
  });

  /* 한 수(이벤트) 검증 → 기록 → 상대에게 전달 */
  sock.on("ev", (d, cb) => {
    const room = d && rooms.get(d.room);
    if (!room || room.state !== "play") return ack(cb, { ok: false, msg: "대국이 끝났거나 방이 없습니다." });
    const seat = seatOf(room, sock);
    if (seat < 0) return ack(cb, { ok: false, msg: "이 대국의 대국자가 아닙니다." });
    const ev = d.ev || {};
    if (ev.c !== seat + 1) return ack(cb, { ok: false, msg: "내 돌 색이 아닙니다." });
    if (ev.s !== room.events.length) return ack(cb, { ok: false, resync: true });
    const g = room.game;
    const elapsed = Date.now() - room.turnStart;
    const timeoutAllowed = elapsed >= room.time * 1000 - TIME_SLACK_MS;
    const clean = { t: ev.t, c: ev.c };
    if (ev.i !== undefined) clean.i = ev.i | 0;
    if (ev.to) clean.to = ev.to | 0;
    if (ev.h !== undefined) clean.h = String(ev.h).slice(0, 4000);
    const turnBefore = g.turn, movesBefore = g.moveNumber;
    const r = Rules.applyEvent(g, clean, { timeoutAllowed });
    if (!r.ok) return ack(cb, { ok: false, resync: true, msg: r.msg });
    clean.s = room.events.length;
    room.events.push(clean);
    if (g.turn !== turnBefore || g.moveNumber !== movesBefore) room.turnStart = Date.now();
    ack(cb, { ok: true });
    const opp = room.players[1 - seat];
    emitTo(opp, "ev", clean);
    if (g.phase === "over") { room.state = "over"; updateRatings(room); }
  });

  sock.on("finished", () => {});   // 게임 화면이 종료를 알림 (판정은 서버 기록 기준)

  sock.on("sync", (d, cb) => {
    const room = d && rooms.get(d.room);
    if (!room || seatOf(room, sock) < 0) return ack(cb, { ok: false });
    ack(cb, { ok: true, events: room.events });
  });

  /* 다시 연결: 토큰으로 내 자리 되찾기 */
  sock.on("rejoin", (d, cb) => {
    const room = d && rooms.get(d.room);
    if (!room) return ack(cb, { ok: false, msg: "대국이 이미 끝났습니다." });
    const seat = room.players.findIndex(p => p.token === d.token);
    if (seat < 0) return ack(cb, { ok: false, msg: "대국 정보를 찾을 수 없습니다." });
    const p = room.players[seat];
    if (p.sid && p.sid !== sock.id) sockRoom.delete(p.sid);
    p.sid = sock.id; p.online = true; clearTimeout(p.graceTimer);
    sockRoom.set(sock.id, room.id);
    if (room.state === "pending") {                     // 링크를 보내고 돌아온 방장
      ack(cb, { ok: true, events: [] });
      if (room.waitingHost && room.players.length === 2) { room.waitingHost = false; startGame(room); }
      return;
    }
    const opp = room.players[1 - seat];
    ack(cb, { ok: true, events: room.events, oppOnline: !!opp.online });
    emitTo(opp, "opp_status", { online: true });
  });

  sock.on("rematch", (d, cb) => {
    const room = d && rooms.get(d.room);
    if (!room || room.state !== "over") return ack(cb, { ok: false, msg: "대국이 끝난 뒤에 재대국을 신청할 수 있습니다." });
    const seat = seatOf(room, sock);
    if (seat < 0) return ack(cb, { ok: false });
    const opp = room.players[1 - seat];
    if (!opp.online) return ack(cb, { ok: false, msg: "상대가 나갔습니다." });
    room.rematch[seat] = true;
    ack(cb, { ok: true });
    if (room.rematch[0] && room.rematch[1]) { room.players.reverse(); startGame(room); }   // 흑백을 바꿔 시작
    else emitTo(opp, "opp_rematch", {});
  });

  sock.on("leave", d => {
    const room = d && rooms.get(d.room);
    if (!room) return;
    const seat = seatOf(room, sock);
    if (seat < 0) return;
    const opp = room.players[1 - seat];
    if (room.state === "play" && room.game) {           // 대국 중에 나가면 기권으로 기록
      const ev = { t: "r", c: seat + 1, s: room.events.length };
      if (Rules.applyEvent(room.game, ev).ok) { room.events.push(ev); room.state = "over"; updateRatings(room); }
    }
    emitTo(opp, "opp_left", {});
    sockRoom.delete(sock.id);
    room.players[seat].sid = ""; room.players[seat].online = false;
    if (!opp || !opp.online) endRoom(room);
  });

  sock.on("disconnect", () => {
    removeFromQueues(sock);
    const room = rooms.get(sockRoom.get(sock.id));
    sockRoom.delete(sock.id);
    if (!room) return;
    const seat = seatOf(room, sock);
    if (seat < 0) return;
    const p = room.players[seat];
    p.online = false;
    if (room.state === "pending") return;               // 초대 방은 10분 동안 유지 (방장이 링크를 보내러 나가도 됨)
    const opp = room.players[1 - seat];
    if (room.state === "over") { if (!opp.online) endRoom(room); else emitTo(opp, "opp_left", {}); return; }
    emitTo(opp, "opp_status", { online: false, grace: GRACE_SEC });
    p.graceTimer = setTimeout(() => {
      if (p.online || room.state !== "play") return;
      const ev = { t: "r", c: seat + 1, s: room.events.length };
      if (Rules.applyEvent(room.game, ev).ok) { room.events.push(ev); room.state = "over"; updateRatings(room); }
      emitTo(opp, "opp_gone", {});
      if (!opp.online) endRoom(room);
    }, GRACE_SEC * 1000);
  });
});

/* 끝난 방 정리 (30분마다) */
setInterval(() => {
  for (const r of rooms.values()) if (r.state === "over" && !r.players.some(p => p.online)) endRoom(r);
}, 30 * 60 * 1000).unref();

server.listen(PORT, () => console.log(`HANOK3D GO 대국 서버 v${PROTOCOL_V} · 포트 ${PORT} · 판: ${Object.values(BOARDS).map(b => b.code).join(" / ")}`));
module.exports = { server, io, BOARDS };
