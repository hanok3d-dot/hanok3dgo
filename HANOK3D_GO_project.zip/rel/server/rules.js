/* 자동 생성: game/HANOK3D_GO.html의 hanok-core에서 추출 (직접 고치지 마세요) */
// @ts-check
/* =====================================================================
   HANOK3D GO · 공간바둑 규칙 엔진 (순수 함수, DOM 없음)
   - 브라우저(AI Web Worker), Node 서버(서버 권위 판정)에서 똑같이 사용
   - 게임 화면(src/game/03-state-rules.js)의 playMove·isLegal·checkNoMoves·computeScore와
     같은 규칙을 그대로 옮긴 것: 6방향 이웃, 따냄, 자충수 금지, 판 모양 반복 금지(패), 중국식 면적 계가
   ===================================================================== */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.HanokRules = api;
})(typeof self !== "undefined" ? self : globalThis, function () {
  "use strict";

  /** @type {Map<number, ReturnType<typeof build>>} */
  const cache = new Map();

  /** n×n×n 판의 규칙 도구 묶음 (판 크기별로 한 번만 만듦) */
  function create(n, l) {
    const L = l || n, k = n * 100 + L;                     // 판 = 가로·세로 n칸 × L층 (l을 생략하면 n×n×n)
    if (!cache.has(k)) cache.set(k, build(n, L));
    return /** @type {ReturnType<typeof build>} */ (cache.get(k));
  }

  function build(N, NL) {
    NL = NL || N;                                           // NL = 층 수 (y), N = 한 층의 가로·세로 칸 수 (x, z)
    const TOTAL = N * N * NL, CENTER = (N - 1) / 2, CY = (NL - 1) / 2;
    const idx = (x, y, z) => x + N * z + N * N * y;
    const coord = i => ({ x: i % N, z: Math.floor(i / N) % N, y: Math.floor(i / (N * N)) });
    /** @type {number[][]} */
    const NEIGHBORS = [];
    for (let i = 0; i < TOTAL; i++) {
      const { x, y, z } = coord(i), nb = [];
      for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        const nx = x + dx, ny = y + dy, nz = z + dz;
        if (nx >= 0 && nx < N && ny >= 0 && ny < NL && nz >= 0 && nz < N) nb.push(idx(nx, ny, nz));
      }
      NEIGHBORS.push(nb);
    }
    const key = b => Array.prototype.join.call(b, "");

    /** 무리와 활로 수 */
    function getGroup(b, start) {
      const color = b[start], stones = [start], liberties = new Set(), visited = new Set([start]), stack = [start];
      while (stack.length) {
        const cur = /** @type {number} */ (stack.pop());
        for (const nb of NEIGHBORS[cur]) {
          if (b[nb] === 0) liberties.add(nb);
          else if (b[nb] === color && !visited.has(nb)) { visited.add(nb); stones.push(nb); stack.push(nb); }
        }
      }
      return { stones, liberties: liberties.size, libs: liberties };
    }

    /** 착수 시도. seen: 이미 나온 판 모양(문자열) 집합 (없으면 패 검사 생략)
        @returns {{ok:true, next:Int8Array, captured:number[], key:string} | {ok:false, reason:string}} */
    function tryPlay(b, index, color, seen) {
      if (!(index >= 0 && index < TOTAL) || (index | 0) !== index) return { ok: false, reason: "range" };
      if (color !== 1 && color !== 2) return { ok: false, reason: "color" };
      if (b[index] !== 0) return { ok: false, reason: "occupied" };
      const opp = 3 - color, next = Int8Array.from(b), captured = [];
      next[index] = color;
      for (const nb of NEIGHBORS[index]) {
        if (next[nb] === opp) {
          const g = getGroup(next, nb);
          if (g.liberties === 0) g.stones.forEach(s => { if (next[s] !== 0) { next[s] = 0; captured.push(s); } });
        }
      }
      if (getGroup(next, index).liberties === 0) return { ok: false, reason: "suicide" };
      if (!seen) return { ok: true, next, captured, key: "" };      // 패 검사 없음(무작위 끝내기용): 문자열 만들기 생략
      const k = key(next);
      if (seen.has(k)) return { ok: false, reason: "ko" };
      return { ok: true, next, captured, key: k };
    }
    const isLegal = (b, i, color, seen) => b[i] === 0 && tryPlay(b, i, color, seen).ok;
    function hasLegalMove(b, color, seen) {
      for (let i = 0; i < TOTAL; i++) if (b[i] === 0 && isLegal(b, i, color, seen)) return true;
      return false;
    }

    /** 계가: 판 위의 돌 + 한 색으로만 둘러싸인 빈 점 (중국식 면적) */
    function computeScore(b) {
      const stones = { 1: 0, 2: 0 }, area = { 1: 0, 2: 0 };
      const terr = new Int8Array(TOTAL), visited = new Uint8Array(TOTAL);
      for (let i = 0; i < TOTAL; i++) {
        if (b[i]) { stones[b[i]]++; continue; }
        if (visited[i]) continue;
        const region = [], stack = [i], border = new Set();
        visited[i] = 1;
        while (stack.length) {
          const p = /** @type {number} */ (stack.pop()); region.push(p);
          for (const q of NEIGHBORS[p]) {
            if (b[q]) border.add(b[q]);
            else if (!visited[q]) { visited[q] = 1; stack.push(q); }
          }
        }
        if (border.size === 1) {
          const c = border.values().next().value;
          area[c] += region.length;
          region.forEach(r => { terr[r] = c; });
        }
      }
      return { stones, area, terr };
    }
    /** 사석(죽은 돌)을 들어낸 판으로 계가. dead: 죽은 돌 자리 목록 */
    function scoreWithDead(b, dead) {
      const nb = Int8Array.from(b), deadCount = { 1: 0, 2: 0 };
      for (const i of dead || []) if (nb[i]) { deadCount[nb[i]]++; nb[i] = 0; }
      const s = computeScore(nb);
      return Object.assign(s, { dead: deadCount, board: nb });
    }
    /** 사석 표시를 무리 단위로 켜고 끔 (같은 색으로 이어진 돌 전체) */
    function toggleDead(b, deadSet, i) {
      if (!b[i]) return deadSet;
      const g = getGroup(b, i), on = !deadSet.has(i), out = new Set(deadSet);
      g.stones.forEach(s => { if (on) out.add(s); else out.delete(s); });
      return out;
    }
    return { N, NL, TOTAL, CENTER, CY, NEIGHBORS, idx, coord, key, getGroup, tryPlay, isLegal, hasLegalMove, computeScore, scoreWithDead, toggleDead };
  }

  /* =====================================================================
     대국 진행 상태 (서버 권위 판정용). 게임 화면과 같은 순서로 처리:
     착수 → 따냄 → 상대가 둘 곳이 없으면 자동 패스(양쪽 다 없으면 종료)
     양측 연속 패스 → 사석 지정 단계(scoring) → 양측 합의 → 종료
     ===================================================================== */
  const MAX_TIMEOUTS = 3;
  function createGame(n, komi, l) {
    const R = create(n, l);
    const empty = new Int8Array(R.TOTAL);
    const g = {
      n, komi: +komi || 0, R,
      board: empty, turn: 1, passCount: 0, moveNumber: 0, lastMove: -1,
      captures: { 1: 0, 2: 0 }, outs: { 1: 0, 2: 0 },
      seen: new Set([R.key(empty)]),
      phase: "play",                 // play | scoring | over
      dead: new Set(), agree: { 1: "", 2: "" },
      result: null,                  // { winner, reason, b, w }
      endReason: ""
    };
    return g;
  }
  function deadHash(dead) { return [...dead].sort((a, b) => a - b).join("."); }
  function enterScoring(g, reason) { g.phase = "scoring"; g.dead = new Set(); g.agree = { 1: "", 2: "" }; g.endReason = reason; }
  function afterTurn(g) {                       // 게임 화면의 checkNoMoves와 같음
    if (g.phase !== "play") return;
    const me = g.turn;
    if (g.R.hasLegalMove(g.board, me, g.seen)) return;
    if (!g.R.hasLegalMove(g.board, 3 - me, g.seen)) { enterScoring(g, "nomove"); return; }
    g.passCount++; g.moveNumber++; g.turn = 3 - me; g.lastMove = -1;
    if (g.passCount >= 2) enterScoring(g, "nomove");
  }
  /** 이벤트 하나를 검증하고 적용. 실패하면 { ok:false, msg } (상태는 그대로) */
  function applyEvent(g, ev, opts) {
    opts = opts || {};
    const c = ev && ev.c;
    if (c !== 1 && c !== 2) return { ok: false, msg: "bad color" };
    switch (ev.t) {
      case "m": {
        if (g.phase !== "play") return { ok: false, msg: "not playing" };
        if (c !== g.turn) return { ok: false, msg: "not your turn" };
        const r = g.R.tryPlay(g.board, ev.i, c, g.seen);
        if (!r.ok) return { ok: false, msg: "illegal: " + r.reason };
        g.board = r.next; g.captures[c] += r.captured.length; g.lastMove = ev.i;
        g.passCount = 0; g.moveNumber++; g.seen.add(r.key); g.turn = 3 - c;
        afterTurn(g);
        return { ok: true };
      }
      case "p": {
        if (g.phase !== "play") return { ok: false, msg: "not playing" };
        if (c !== g.turn) return { ok: false, msg: "not your turn" };
        if (ev.to) {                                     // 시간 초과로 인한 자동 패스
          if (ev.to !== g.outs[c] + 1 || ev.to >= MAX_TIMEOUTS) return { ok: false, msg: "bad timeout count" };
          if (opts.timeoutAllowed === false) return { ok: false, msg: "time not over" };
        }
        g.passCount++; g.moveNumber++; g.turn = 3 - c; g.lastMove = -1;
        if (ev.to) g.outs[c] = ev.to;
        if (g.passCount >= 2) enterScoring(g, "pass"); else afterTurn(g);
        return { ok: true };
      }
      case "x": {                                        // 시간 초과 3회: 시간패
        if (g.phase !== "play") return { ok: false, msg: "not playing" };
        if (c !== g.turn || g.outs[c] !== MAX_TIMEOUTS - 1) return { ok: false, msg: "bad time loss" };
        if (opts.timeoutAllowed === false) return { ok: false, msg: "time not over" };
        g.outs[c] = MAX_TIMEOUTS; g.phase = "over";
        g.result = { winner: 3 - c, reason: "time" };
        return { ok: true };
      }
      case "r": {                                        // 기권 (언제든 자기 색으로만)
        if (g.phase === "over") return { ok: false, msg: "already over" };
        g.phase = "over"; g.result = { winner: 3 - c, reason: "resign" };
        return { ok: true };
      }
      case "d": {                                        // 사석 표시 켜기/끄기 (무리 단위) → 합의 초기화
        if (g.phase !== "scoring") return { ok: false, msg: "not scoring" };
        if (!(ev.i >= 0 && ev.i < g.R.TOTAL) || !g.board[ev.i]) return { ok: false, msg: "no stone" };
        g.dead = g.R.toggleDead(g.board, g.dead, ev.i);
        g.agree = { 1: "", 2: "" };
        return { ok: true };
      }
      case "a": {                                        // 합의: 지금 사석 표시(해시)에 동의
        if (g.phase !== "scoring") return { ok: false, msg: "not scoring" };
        if (ev.h !== deadHash(g.dead)) return { ok: false, msg: "stale agreement" };
        g.agree[c] = ev.h;
        if (g.agree[1] === ev.h && g.agree[2] === ev.h) {
          const s = g.R.scoreWithDead(g.board, g.dead);
          const b = s.stones[1] + s.area[1], w = s.stones[2] + s.area[2] + g.komi;
          g.phase = "over";
          g.result = { winner: b > w ? 1 : w > b ? 2 : 0, reason: "score", b, w };
        }
        return { ok: true };
      }
      case "u": {                                        // 사석 합의가 안 되면 이어 두기
        if (g.phase !== "scoring") return { ok: false, msg: "not scoring" };
        g.phase = "play"; g.passCount = 0; g.dead = new Set(); g.agree = { 1: "", 2: "" };
        if (!g.R.hasLegalMove(g.board, g.turn, g.seen)) g.turn = 3 - g.turn;
        return { ok: true };
      }
      default: return { ok: false, msg: "unknown event" };
    }
  }
  return { create, createGame, applyEvent, deadHash, MAX_TIMEOUTS };
});
