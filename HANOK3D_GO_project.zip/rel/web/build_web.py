"""index.template.html + 자산 → 자체 완결형 index.html (서버용 / 게시용)"""
import base64, re, sys, mimetypes, json
A='/tmp/web/'
MIME={'.webp':'image/webp','.jpg':'image/jpeg','.png':'image/png','.mp4':'video/mp4'}
def build(cfg, out):
    s=open('/home/claude/web/index.template.html',encoding='utf-8').read()
    def sub(m):
        name=m.group(1); ext=name[name.rfind('.'):]
        return f"data:{MIME[ext]};base64,"+base64.b64encode(open(A+name,'rb').read()).decode()
    s=re.sub(r'\{\{([\w.]+)\}\}', sub, s)
    for k,v in cfg.items():
        s=re.sub(rf'  {k}: [^,\n]+(,?)', lambda m: f'  {k}: {json.dumps(v,ensure_ascii=False)}{m.group(1)}', s, count=1)
    open(out,'w',encoding='utf-8').write(s); print(out, len(s)//1024, 'KB')
if __name__=='__main__':
    cfg=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
    build(cfg, sys.argv[1])
