/* hanok.config.json → 안드로이드 프로젝트에 반영
   - 패키지 이름(applicationId), 버전(versionCode/versionName), 앱 이름
   - 릴리스 서명: 환경 변수(CI) 또는 android/keystore.properties
   - 초대 링크 https://서버/j/1234 를 앱으로 바로 여는 앱 링크(intent-filter)
   여러 번 실행해도 같은 결과가 나오도록 작성 */
"use strict";
const fs = require("fs"), path = require("path");
const ROOT = path.join(__dirname, "..");
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, "hanok.config.json"), "utf8"));
const A = path.join(__dirname, "android", "app");
const read = f => fs.readFileSync(f, "utf8"), write = (f, s) => fs.writeFileSync(f, s);

/* 1) build.gradle */
const g = path.join(A, "build.gradle");
let s = read(g);
s = s.replace(/applicationId "[^"]*"/, `applicationId "${cfg.appId}"`)
     .replace(/versionCode \d+/, `versionCode ${+process.env.HANOK_VERSION_CODE || cfg.versionCode}`)
     .replace(/versionName "[^"]*"/, `versionName "${cfg.version}"`);
if (!s.includes("// HANOK-SIGNING")) {
  s = s.replace(/android \{\n/, `android {
    // HANOK-SIGNING: 업로드 키로 서명 (CI 환경 변수 또는 android/keystore.properties)
    def ksProps = new Properties()
    def ksFile = rootProject.file("keystore.properties")
    if (ksFile.exists()) ksFile.withInputStream { ksProps.load(it) }
    def ksPath = System.getenv("HANOK_KEYSTORE") ?: ksProps.getProperty("storeFile")
    signingConfigs {
        release {
            if (ksPath) {
                storeFile file(ksPath)
                storePassword System.getenv("HANOK_KEYSTORE_PASSWORD") ?: ksProps.getProperty("storePassword")
                keyAlias System.getenv("HANOK_KEY_ALIAS") ?: ksProps.getProperty("keyAlias")
                keyPassword System.getenv("HANOK_KEY_PASSWORD") ?: ksProps.getProperty("keyPassword")
            }
        }
    }
`);
  s = s.replace(/release \{\n(\s*)minifyEnabled false/, (m, sp) => `release {\n${sp}if (ksPath) signingConfig signingConfigs.release\n${sp}minifyEnabled false`);
}
write(g, s);

/* 2) 앱 이름 */
const st = path.join(A, "src", "main", "res", "values", "strings.xml");
write(st, read(st).replace(/(<string name="app_name">)[^<]*/, `$1${cfg.appName}`).replace(/(<string name="title_activity_main">)[^<]*/, `$1${cfg.appName}`));

/* 3) 초대 링크 → 앱 열기 (서버 주소가 정해졌을 때만) */
const mf = path.join(A, "src", "main", "AndroidManifest.xml");
let m = read(mf).replace(/\n\s*<!-- HANOK-APPLINK -->[\s\S]*?<!-- \/HANOK-APPLINK -->/, "");
let host = "";
try { const u = new URL(cfg.server); if (u.protocol === "https:" && !/YOUR-SERVER/i.test(u.host)) host = u.host; } catch (e) {}
if (host) {
  m = m.replace(/(<category android:name="android.intent.category.LAUNCHER" \/>\s*<\/intent-filter>)/, `$1
            <!-- HANOK-APPLINK -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="${host}" android:pathPrefix="/j/" />
            </intent-filter>
            <!-- /HANOK-APPLINK -->`);
  console.log("✔ 앱 링크: https://" + host + "/j/****");
} else console.warn("⚠ 서버 주소가 없어 앱 링크(초대 링크로 앱 열기)는 넣지 않았습니다.");
write(mf, m);
console.log(`✔ ${cfg.appId} · v${cfg.version} (${cfg.versionCode}) · "${cfg.appName}"`);
