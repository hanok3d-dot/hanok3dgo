package com.hanok3d.go;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
