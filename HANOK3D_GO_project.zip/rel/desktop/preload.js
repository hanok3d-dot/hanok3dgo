/* 게임이 PC판임을 알 수 있게 표시 (서버 설정 칸 숨김 · 서비스 워커 생략) + 종료 버튼 */
const { contextBridge } = require("electron");
contextBridge.exposeInMainWorld("hanokDesktop", { platform: process.platform, version: process.versions.electron });
contextBridge.exposeInMainWorld("HanokApp", { exitApp: () => window.close(), setLandscape() {}, setPortrait() {}, share: null });
