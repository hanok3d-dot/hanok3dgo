/* HANOK3D GO PC판 (Electron): 게임 HTML을 창으로 띄움. 서버 주소는 build.js가 HTML에 이미 넣어 둠 */
"use strict";
const { app, BrowserWindow, shell, Menu } = require("electron");
const path = require("path");
if (!app.requestSingleInstanceLock()) app.quit();
let win = null;
function create() {
  win = new BrowserWindow({
    width: 1280, height: 860, minWidth: 360, minHeight: 600, backgroundColor: "#0a1810", title: "HANOK3D GO",
    icon: path.join(__dirname, "build", "icon.png"), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, sandbox: true },
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, "app", "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: "deny" }; });
  win.webContents.on("will-navigate", (e, url) => { if (!url.startsWith("file:")) { e.preventDefault(); shell.openExternal(url); } });
  win.webContents.on("before-input-event", (e, i) => { if (i.type === "keyDown" && i.key === "F11") { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); } });
}
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(create);
app.on("window-all-closed", () => app.quit());
